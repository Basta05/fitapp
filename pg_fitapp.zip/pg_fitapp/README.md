# pg_fitapp 💪

Fitness tracker aplikace vytvořená v Django jako semestrální práce.

## Funkce

- 🏋️ **Logování tréninků** – prázdné i pre-set tréninky, katalog cviků, série a opakování
- 🥗 **Food tracker** – záznamy jídla, makronutrienty, denní přehled kalorií
- 🧮 **Kalkulačka** – výpočet BMR a TDEE (Harris-Benedict)
- 📈 **Progress tracker** – tělesné míry a váha v čase
- 🎯 **Cíle** – nastavení a sledování fitness cílů
- 👤 **Uživatelé** – registrace, přihlášení, nastavení profilu

## Spuštění v GitHub Codespaces

Repozitář je připraven pro GitHub Codespaces. Stačí:

1. Klikni na zelené tlačítko **Code → Codespaces → Create codespace on main**
2. Počkej na automatickou instalaci (`postCreateCommand` se spustí sám)
3. Spusť server:

```bash
python manage.py runserver 0.0.0.0:8000
```

4. Codespaces automaticky nabídne otevření portu 8000

## Manuální instalace

```bash
# Nainstaluj závislosti
pip install -r requirements.txt

# Vytvoř databázi
python manage.py migrate

# Načti základní data (cviky a jídla)
python manage.py loaddata initial_exercises
python manage.py loaddata initial_foods

# Vytvoř admin účet
python manage.py createsuperuser

# Spusť server
python manage.py runserver 0.0.0.0:8000
```

## Přístup

- **Aplikace:** `http://localhost:8000`
- **Admin panel:** `http://localhost:8000/admin`

## Struktura projektu

```
pg_fitapp/
├── pg_fitapp/          # Hlavní konfigurace Django
├── workouts/           # Tréninky, cviky, pre-set tréninky
├── nutrition/          # Jídlo, kalorie, makra
├── goals/              # Cíle, tělesné míry
├── users/              # Uživatelé, profil, nastavení
├── templates/          # HTML šablony
├── static/             # CSS, JS, obrázky
└── requirements.txt
```

## Technologie

- **Backend:** Django 4.2, Python 3.11
- **Databáze:** SQLite
- **Frontend:** Bootstrap 5, Chart.js
- **Deployment:** GitHub Codespaces

## Git workflow

```bash
# Před začátkem práce vždy stáhni změny
git pull origin main

# Vytvoř větev pro svoji práci
git checkout -b feature/nazev-funkce

# Po dokončení nahraj a vytvoř Pull Request
git add .
git commit -m "Popis změn"
git push origin feature/nazev-funkce
```
