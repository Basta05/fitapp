from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import FoodLog, FoodItem, NutritionGoal


@login_required
def nutrition_dashboard(request):
    today = timezone.now().date()
    logs = FoodLog.objects.filter(user=request.user, date=today)
    total_calories = sum(log.calories for log in logs)
    total_protein = sum(log.protein for log in logs)
    total_carbs = sum(log.carbs for log in logs)
    total_fat = sum(log.fat for log in logs)
    goal = NutritionGoal.objects.filter(user=request.user).first()
    context = {
        'logs': logs,
        'total_calories': total_calories,
        'total_protein': total_protein,
        'total_carbs': total_carbs,
        'total_fat': total_fat,
        'goal': goal,
        'today': today,
    }
    return render(request, 'nutrition/dashboard.html', context)


@login_required
def food_log(request):
    date_str = request.GET.get('date', str(timezone.now().date()))
    logs = FoodLog.objects.filter(user=request.user, date=date_str)
    return render(request, 'nutrition/food_log.html', {'logs': logs, 'date': date_str})


@login_required
def food_log_add(request):
    if request.method == 'POST':
        food_id = request.POST.get('food_item')
        date = request.POST.get('date')
        meal_type = request.POST.get('meal_type')
        amount = request.POST.get('amount_grams')
        FoodLog.objects.create(
            user=request.user,
            food_item_id=food_id,
            date=date,
            meal_type=meal_type,
            amount_grams=amount,
        )
        return redirect('nutrition:dashboard')
    foods = FoodItem.objects.all()
    today = timezone.now().date()
    return render(request, 'nutrition/food_log_add.html', {'foods': foods, 'today': today})


@login_required
def food_log_delete(request, pk):
    log = get_object_or_404(FoodLog, pk=pk, user=request.user)
    if request.method == 'POST':
        log.delete()
    return redirect('nutrition:dashboard')


@login_required
def calorie_calculator(request):
    result = None
    if request.method == 'POST':
        try:
            weight = float(request.POST.get('weight', 0))
            height = float(request.POST.get('height', 0))
            age = int(request.POST.get('age', 0))
            gender = request.POST.get('gender', 'male')
            activity = request.POST.get('activity', 'moderate')
            if gender == 'male':
                bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
            else:
                bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
            factors = {
                'sedentary': 1.2, 'light': 1.375,
                'moderate': 1.55, 'active': 1.725, 'very_active': 1.9,
            }
            tdee = round(bmr * factors.get(activity, 1.55))
            result = {'bmr': round(bmr), 'tdee': tdee, 'cut': tdee - 500, 'bulk': tdee + 300}
        except (ValueError, ZeroDivisionError):
            pass
    return render(request, 'nutrition/calculator.html', {'result': result})


@login_required
def nutrition_goals(request):
    goal, _ = NutritionGoal.objects.get_or_create(
        user=request.user,
        defaults={'daily_calories': 2000, 'daily_protein': 150, 'daily_carbs': 200, 'daily_fat': 65}
    )
    if request.method == 'POST':
        goal.daily_calories = request.POST.get('daily_calories')
        goal.daily_protein = request.POST.get('daily_protein')
        goal.daily_carbs = request.POST.get('daily_carbs')
        goal.daily_fat = request.POST.get('daily_fat')
        goal.save()
        return redirect('nutrition:dashboard')
    return render(request, 'nutrition/goals.html', {'goal': goal})


@login_required
def food_search(request):
    query = request.GET.get('q', '')
    foods = FoodItem.objects.filter(name__icontains=query) if query else FoodItem.objects.all()
    return render(request, 'nutrition/food_search.html', {'foods': foods, 'query': query})
