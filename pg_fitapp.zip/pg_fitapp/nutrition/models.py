from django.db import models
from django.contrib.auth.models import User


class FoodItem(models.Model):
    """Databáze jídel"""
    name = models.CharField(max_length=150, verbose_name='Název')
    calories_per_100g = models.DecimalField(max_digits=6, decimal_places=1, verbose_name='Kalorie / 100g')
    protein_per_100g = models.DecimalField(max_digits=5, decimal_places=1, verbose_name='Bílkoviny / 100g')
    carbs_per_100g = models.DecimalField(max_digits=5, decimal_places=1, verbose_name='Sacharidy / 100g')
    fat_per_100g = models.DecimalField(max_digits=5, decimal_places=1, verbose_name='Tuky / 100g')
    is_custom = models.BooleanField(default=False, verbose_name='Vlastní jídlo')
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='Přidal'
    )

    class Meta:
        verbose_name = 'Jídlo'
        verbose_name_plural = 'Jídla'
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.calories_per_100g} kcal/100g)"


class FoodLog(models.Model):
    """Záznam jídla za den"""
    MEAL_CHOICES = [
        ('breakfast', 'Snídaně'),
        ('lunch', 'Oběd'),
        ('dinner', 'Večeře'),
        ('snack', 'Svačina'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    food_item = models.ForeignKey(FoodItem, on_delete=models.CASCADE, verbose_name='Jídlo')
    date = models.DateField(verbose_name='Datum')
    meal_type = models.CharField(max_length=10, choices=MEAL_CHOICES, verbose_name='Jídlo dne')
    amount_grams = models.DecimalField(max_digits=6, decimal_places=1, verbose_name='Množství (g)')

    class Meta:
        verbose_name = 'Záznam jídla'
        verbose_name_plural = 'Záznamy jídla'
        ordering = ['-date', 'meal_type']

    def __str__(self):
        return f"{self.user.username} – {self.food_item.name} {self.date}"

    @property
    def calories(self):
        return round(float(self.food_item.calories_per_100g) * float(self.amount_grams) / 100, 1)

    @property
    def protein(self):
        return round(float(self.food_item.protein_per_100g) * float(self.amount_grams) / 100, 1)

    @property
    def carbs(self):
        return round(float(self.food_item.carbs_per_100g) * float(self.amount_grams) / 100, 1)

    @property
    def fat(self):
        return round(float(self.food_item.fat_per_100g) * float(self.amount_grams) / 100, 1)


class NutritionGoal(models.Model):
    """Nutriční cíle uživatele"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    daily_calories = models.PositiveIntegerField(verbose_name='Denní kalorie (kcal)')
    daily_protein = models.PositiveIntegerField(verbose_name='Denní bílkoviny (g)')
    daily_carbs = models.PositiveIntegerField(verbose_name='Denní sacharidy (g)')
    daily_fat = models.PositiveIntegerField(verbose_name='Denní tuky (g)')
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Nutriční cíl'
        verbose_name_plural = 'Nutriční cíle'

    def __str__(self):
        return f"Cíle – {self.user.username} ({self.daily_calories} kcal)"
