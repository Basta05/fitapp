from django.contrib import admin
from .models import FoodItem, FoodLog, NutritionGoal


@admin.register(FoodItem)
class FoodItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'calories_per_100g', 'protein_per_100g', 'carbs_per_100g', 'fat_per_100g', 'is_custom']
    list_filter = ['is_custom']
    search_fields = ['name']


@admin.register(FoodLog)
class FoodLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'food_item', 'date', 'meal_type', 'amount_grams']
    list_filter = ['meal_type', 'date']
    search_fields = ['user__username', 'food_item__name']


@admin.register(NutritionGoal)
class NutritionGoalAdmin(admin.ModelAdmin):
    list_display = ['user', 'daily_calories', 'daily_protein', 'daily_carbs', 'daily_fat']
