from django.urls import path
from . import views

app_name = 'nutrition'

urlpatterns = [
    path('', views.nutrition_dashboard, name='dashboard'),
    path('log/', views.food_log, name='food_log'),
    path('log/add/', views.food_log_add, name='food_log_add'),
    path('log/<int:pk>/delete/', views.food_log_delete, name='food_log_delete'),
    path('calculator/', views.calorie_calculator, name='calculator'),
    path('goals/', views.nutrition_goals, name='goals'),
    path('foods/', views.food_search, name='food_search'),
]
