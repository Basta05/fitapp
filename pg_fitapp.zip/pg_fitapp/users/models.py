from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    """Rozšířený profil uživatele"""
    GENDER_CHOICES = [
        ('male', 'Muž'),
        ('female', 'Žena'),
        ('other', 'Jiné'),
    ]
    ACTIVITY_CHOICES = [
        ('sedentary', 'Sedavý životní styl'),
        ('light', 'Lehká aktivita (1–3x týdně)'),
        ('moderate', 'Střední aktivita (3–5x týdně)'),
        ('active', 'Vysoká aktivita (6–7x týdně)'),
        ('very_active', 'Velmi vysoká aktivita'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True, verbose_name='Pohlaví')
    date_of_birth = models.DateField(null=True, blank=True, verbose_name='Datum narození')
    height_cm = models.PositiveIntegerField(null=True, blank=True, verbose_name='Výška (cm)')
    starting_weight_kg = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Počáteční váha (kg)')
    activity_level = models.CharField(max_length=15, choices=ACTIVITY_CHOICES, default='moderate', verbose_name='Úroveň aktivity')
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True, verbose_name='Profilová fotka')
    bio = models.TextField(blank=True, verbose_name='O mně')

    class Meta:
        verbose_name = 'Profil'
        verbose_name_plural = 'Profily'

    def __str__(self):
        return f"Profil – {self.user.username}"

    def calculate_bmr(self, current_weight_kg):
        """Harris-Benedict vzorec pro výpočet BMR"""
        if not self.height_cm or not self.date_of_birth:
            return None
        from datetime import date
        age = (date.today() - self.date_of_birth).days // 365
        w = float(current_weight_kg)
        h = float(self.height_cm)
        if self.gender == 'male':
            return round(88.362 + (13.397 * w) + (4.799 * h) - (5.677 * age))
        elif self.gender == 'female':
            return round(447.593 + (9.247 * w) + (3.098 * h) - (4.330 * age))
        return None

    def calculate_tdee(self, current_weight_kg):
        """TDEE = BMR * faktor aktivity"""
        bmr = self.calculate_bmr(current_weight_kg)
        if not bmr:
            return None
        factors = {
            'sedentary': 1.2,
            'light': 1.375,
            'moderate': 1.55,
            'active': 1.725,
            'very_active': 1.9,
        }
        return round(bmr * factors.get(self.activity_level, 1.55))
