from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import login
from .models import UserProfile


def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 != password2:
            return render(request, 'users/register.html', {'error': 'Hesla se neshodují'})
        if User.objects.filter(username=username).exists():
            return render(request, 'users/register.html', {'error': 'Uživatelské jméno již existuje'})
        user = User.objects.create_user(username=username, email=email, password=password1)
        UserProfile.objects.create(user=user)
        login(request, user)
        return redirect('workouts:dashboard')
    return render(request, 'users/register.html')


@login_required
def profile(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    return render(request, 'users/profile.html', {'profile': profile})


@login_required
def settings_view(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        profile.gender = request.POST.get('gender', '')
        profile.date_of_birth = request.POST.get('date_of_birth') or None
        profile.height_cm = request.POST.get('height_cm') or None
        profile.activity_level = request.POST.get('activity_level', 'moderate')
        profile.bio = request.POST.get('bio', '')
        profile.save()
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        request.user.email = request.POST.get('email', '')
        request.user.save()
        return redirect('users:profile')
    return render(request, 'users/settings.html', {'profile': profile})
