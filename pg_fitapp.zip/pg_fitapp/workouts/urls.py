from django.urls import path
from . import views

app_name = 'workouts'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('workouts/', views.workout_list, name='workout_list'),
    path('workouts/new/', views.workout_new, name='workout_new'),
    path('workouts/<int:pk>/', views.workout_detail, name='workout_detail'),
    path('workouts/<int:pk>/delete/', views.workout_delete, name='workout_delete'),
    path('exercises/', views.exercise_catalog, name='exercise_catalog'),
    path('presets/', views.preset_list, name='preset_list'),
    path('presets/<int:pk>/start/', views.preset_start, name='preset_start'),
]
