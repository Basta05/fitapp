from django.contrib import admin
from .models import Exercise, Workout, WorkoutExercise, ExerciseSet, PresetWorkout


class ExerciseSetInline(admin.TabularInline):
    model = ExerciseSet
    extra = 3


class WorkoutExerciseInline(admin.TabularInline):
    model = WorkoutExercise
    extra = 2


@admin.register(Exercise)
class ExerciseAdmin(admin.ModelAdmin):
    list_display = ['name', 'muscle_group', 'is_preset']
    list_filter = ['muscle_group', 'is_preset']
    search_fields = ['name']


@admin.register(Workout)
class WorkoutAdmin(admin.ModelAdmin):
    list_display = ['name', 'user', 'date', 'duration_minutes', 'workout_type']
    list_filter = ['workout_type', 'date']
    search_fields = ['name', 'user__username']
    inlines = [WorkoutExerciseInline]


@admin.register(PresetWorkout)
class PresetWorkoutAdmin(admin.ModelAdmin):
    list_display = ['name', 'muscle_focus', 'difficulty']
    list_filter = ['difficulty', 'muscle_focus']
    filter_horizontal = ['exercises']
