from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Workout, Exercise, PresetWorkout


@login_required
def dashboard(request):
    recent_workouts = Workout.objects.filter(user=request.user)[:5]
    total_workouts = Workout.objects.filter(user=request.user).count()
    context = {
        'recent_workouts': recent_workouts,
        'total_workouts': total_workouts,
    }
    return render(request, 'workouts/dashboard.html', context)


@login_required
def workout_list(request):
    workouts = Workout.objects.filter(user=request.user)
    return render(request, 'workouts/workout_list.html', {'workouts': workouts})


@login_required
def workout_new(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        date = request.POST.get('date')
        notes = request.POST.get('notes', '')
        workout = Workout.objects.create(
            user=request.user,
            name=name,
            date=date,
            notes=notes,
        )
        return redirect('workouts:workout_detail', pk=workout.pk)
    today = timezone.now().date()
    return render(request, 'workouts/workout_form.html', {'today': today})


@login_required
def workout_detail(request, pk):
    workout = get_object_or_404(Workout, pk=pk, user=request.user)
    return render(request, 'workouts/workout_detail.html', {'workout': workout})


@login_required
def workout_delete(request, pk):
    workout = get_object_or_404(Workout, pk=pk, user=request.user)
    if request.method == 'POST':
        workout.delete()
        return redirect('workouts:workout_list')
    return render(request, 'workouts/workout_confirm_delete.html', {'workout': workout})


@login_required
def exercise_catalog(request):
    muscle_group = request.GET.get('muscle_group', '')
    exercises = Exercise.objects.all()
    if muscle_group:
        exercises = exercises.filter(muscle_group=muscle_group)
    return render(request, 'workouts/exercise_catalog.html', {
        'exercises': exercises,
        'muscle_groups': Exercise.objects.values_list('muscle_group', flat=True).distinct(),
    })


@login_required
def preset_list(request):
    presets = PresetWorkout.objects.all()
    return render(request, 'workouts/preset_list.html', {'presets': presets})


@login_required
def preset_start(request, pk):
    preset = get_object_or_404(PresetWorkout, pk=pk)
    workout = Workout.objects.create(
        user=request.user,
        name=preset.name,
        date=timezone.now().date(),
        workout_type='preset',
    )
    return redirect('workouts:workout_detail', pk=workout.pk)
