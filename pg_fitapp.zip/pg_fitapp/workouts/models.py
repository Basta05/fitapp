from django.db import models
from django.contrib.auth.models import User


class MuscleGroup(models.TextChoices):
    CHEST = 'chest', 'Hrudník'
    BACK = 'back', 'Záda'
    SHOULDERS = 'shoulders', 'Ramena'
    BICEPS = 'biceps', 'Biceps'
    TRICEPS = 'triceps', 'Triceps'
    LEGS = 'legs', 'Nohy'
    GLUTES = 'glutes', 'Hýždě'
    ABS = 'abs', 'Břicho'
    CARDIO = 'cardio', 'Kardio'
    FULL_BODY = 'full_body', 'Celé tělo'


class Exercise(models.Model):
    """Katalog cviků – sdílený pro všechny uživatele"""
    name = models.CharField(max_length=100, verbose_name='Název cviku')
    muscle_group = models.CharField(
        max_length=20,
        choices=MuscleGroup.choices,
        verbose_name='Svalová skupina'
    )
    description = models.TextField(blank=True, verbose_name='Popis')
    is_preset = models.BooleanField(default=True, verbose_name='Přednastavený cvik')
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name='Vytvořil'
    )

    class Meta:
        verbose_name = 'Cvik'
        verbose_name_plural = 'Cviky'
        ordering = ['muscle_group', 'name']

    def __str__(self):
        return f"{self.name} ({self.get_muscle_group_display()})"


class Workout(models.Model):
    """Jeden trénink uživatele"""
    WORKOUT_TYPES = [
        ('custom', 'Vlastní'),
        ('preset', 'Přednastavený'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    name = models.CharField(max_length=100, verbose_name='Název tréninku')
    date = models.DateField(verbose_name='Datum')
    duration_minutes = models.PositiveIntegerField(null=True, blank=True, verbose_name='Délka (min)')
    workout_type = models.CharField(max_length=10, choices=WORKOUT_TYPES, default='custom')
    notes = models.TextField(blank=True, verbose_name='Poznámky')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Trénink'
        verbose_name_plural = 'Tréninky'
        ordering = ['-date']

    def __str__(self):
        return f"{self.name} – {self.date} ({self.user.username})"


class WorkoutExercise(models.Model):
    """Cvik v rámci konkrétního tréninku"""
    workout = models.ForeignKey(Workout, on_delete=models.CASCADE, related_name='exercises')
    exercise = models.ForeignKey(Exercise, on_delete=models.CASCADE)
    order = models.PositiveIntegerField(default=0, verbose_name='Pořadí')

    class Meta:
        ordering = ['order']
        verbose_name = 'Cvik v tréninku'
        verbose_name_plural = 'Cviky v tréninku'

    def __str__(self):
        return f"{self.exercise.name} v {self.workout.name}"


class ExerciseSet(models.Model):
    """Jedna série cviku"""
    workout_exercise = models.ForeignKey(WorkoutExercise, on_delete=models.CASCADE, related_name='sets')
    set_number = models.PositiveIntegerField(verbose_name='Číslo série')
    reps = models.PositiveIntegerField(null=True, blank=True, verbose_name='Opakování')
    weight_kg = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Váha (kg)')
    duration_seconds = models.PositiveIntegerField(null=True, blank=True, verbose_name='Délka (s) – pro kardio')
    notes = models.CharField(max_length=200, blank=True, verbose_name='Poznámka')

    class Meta:
        ordering = ['set_number']
        verbose_name = 'Série'
        verbose_name_plural = 'Série'

    def __str__(self):
        return f"Série {self.set_number}: {self.reps} x {self.weight_kg}kg"


class PresetWorkout(models.Model):
    """Přednastavené tréninky – šablony"""
    name = models.CharField(max_length=100, verbose_name='Název')
    description = models.TextField(blank=True, verbose_name='Popis')
    muscle_focus = models.CharField(max_length=20, choices=MuscleGroup.choices, verbose_name='Zaměření')
    exercises = models.ManyToManyField(Exercise, verbose_name='Cviky')
    difficulty = models.CharField(
        max_length=10,
        choices=[('beginner', 'Začátečník'), ('intermediate', 'Středně pokročilý'), ('advanced', 'Pokročilý')],
        default='beginner'
    )

    class Meta:
        verbose_name = 'Přednastavený trénink'
        verbose_name_plural = 'Přednastavené tréninky'

    def __str__(self):
        return self.name
