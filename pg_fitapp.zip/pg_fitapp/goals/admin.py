from django.contrib import admin
from .models import BodyMetrics, UserGoal


@admin.register(BodyMetrics)
class BodyMetricsAdmin(admin.ModelAdmin):
    list_display = ['user', 'date', 'weight_kg', 'body_fat_pct', 'waist_cm']
    list_filter = ['date']
    search_fields = ['user__username']


@admin.register(UserGoal)
class UserGoalAdmin(admin.ModelAdmin):
    list_display = ['user', 'goal_type', 'target_weight_kg', 'target_date', 'is_active']
    list_filter = ['goal_type', 'is_active']
    search_fields = ['user__username']
