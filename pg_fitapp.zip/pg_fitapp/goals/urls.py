from django.urls import path
from . import views

app_name = 'goals'

urlpatterns = [
    path('', views.goals_dashboard, name='dashboard'),
    path('metrics/', views.body_metrics, name='body_metrics'),
    path('metrics/add/', views.body_metrics_add, name='body_metrics_add'),
    path('goals/add/', views.goal_add, name='goal_add'),
    path('goals/<int:pk>/complete/', views.goal_complete, name='goal_complete'),
]
