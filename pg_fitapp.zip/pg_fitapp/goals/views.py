from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import BodyMetrics, UserGoal


@login_required
def goals_dashboard(request):
    active_goals = UserGoal.objects.filter(user=request.user, is_active=True)
    latest_metrics = BodyMetrics.objects.filter(user=request.user).first()
    metrics_history = BodyMetrics.objects.filter(user=request.user)[:10]
    return render(request, 'goals/dashboard.html', {
        'active_goals': active_goals,
        'latest_metrics': latest_metrics,
        'metrics_history': metrics_history,
    })


@login_required
def body_metrics(request):
    metrics = BodyMetrics.objects.filter(user=request.user)
    return render(request, 'goals/body_metrics.html', {'metrics': metrics})


@login_required
def body_metrics_add(request):
    if request.method == 'POST':
        BodyMetrics.objects.update_or_create(
            user=request.user,
            date=request.POST.get('date'),
            defaults={
                'weight_kg': request.POST.get('weight_kg') or None,
                'body_fat_pct': request.POST.get('body_fat_pct') or None,
                'chest_cm': request.POST.get('chest_cm') or None,
                'waist_cm': request.POST.get('waist_cm') or None,
                'hips_cm': request.POST.get('hips_cm') or None,
                'bicep_cm': request.POST.get('bicep_cm') or None,
                'thigh_cm': request.POST.get('thigh_cm') or None,
                'notes': request.POST.get('notes', ''),
            }
        )
        return redirect('goals:dashboard')
    today = timezone.now().date()
    return render(request, 'goals/body_metrics_form.html', {'today': today})


@login_required
def goal_add(request):
    if request.method == 'POST':
        UserGoal.objects.create(
            user=request.user,
            goal_type=request.POST.get('goal_type'),
            target_weight_kg=request.POST.get('target_weight_kg') or None,
            target_date=request.POST.get('target_date') or None,
            description=request.POST.get('description', ''),
        )
        return redirect('goals:dashboard')
    return render(request, 'goals/goal_form.html', {'goal_types': UserGoal.GOAL_TYPES})


@login_required
def goal_complete(request, pk):
    goal = get_object_or_404(UserGoal, pk=pk, user=request.user)
    goal.is_active = False
    goal.save()
    return redirect('goals:dashboard')
