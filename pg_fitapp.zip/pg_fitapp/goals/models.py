from django.db import models
from django.contrib.auth.models import User


class BodyMetrics(models.Model):
    """Tělesné proporce – váha, míry atd."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    date = models.DateField(verbose_name='Datum')
    weight_kg = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Váha (kg)')
    body_fat_pct = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, verbose_name='Tuk (%)')
    chest_cm = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Hrudník (cm)')
    waist_cm = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Pas (cm)')
    hips_cm = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Boky (cm)')
    bicep_cm = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Biceps (cm)')
    thigh_cm = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Stehno (cm)')
    notes = models.TextField(blank=True, verbose_name='Poznámky')

    class Meta:
        verbose_name = 'Tělesné míry'
        verbose_name_plural = 'Tělesné míry'
        ordering = ['-date']
        unique_together = ['user', 'date']

    def __str__(self):
        return f"{self.user.username} – {self.date} ({self.weight_kg} kg)"


class UserGoal(models.Model):
    """Cílová forma uživatele"""
    GOAL_TYPES = [
        ('lose_weight', 'Zhubnout'),
        ('gain_muscle', 'Nabrat svaly'),
        ('maintain', 'Udržet váhu'),
        ('improve_endurance', 'Zlepšit kondici'),
        ('other', 'Jiný'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Uživatel')
    goal_type = models.CharField(max_length=20, choices=GOAL_TYPES, verbose_name='Typ cíle')
    target_weight_kg = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name='Cílová váha (kg)')
    target_date = models.DateField(null=True, blank=True, verbose_name='Datum splnění')
    description = models.TextField(blank=True, verbose_name='Popis cíle')
    is_active = models.BooleanField(default=True, verbose_name='Aktivní')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Cíl'
        verbose_name_plural = 'Cíle'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} – {self.get_goal_type_display()}"
